#ifndef EXECUTECOMMAND_H
#define EXECUTECOMMAND_H
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

// Function to extract content from a given HTTP URL
void executeCommand(char* argv0, char *command);

#endif
